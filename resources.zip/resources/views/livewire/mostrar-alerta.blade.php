<div class="border  boder-red-400 bg-red-100 text-red-800 font-bold uppercase p-2 text-xs mt-2">
    <p>{{$message}}</p>
</div>
