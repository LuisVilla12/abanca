<div>
    <img src="<?php echo e(asset('img/Personajes xicoclass.png')); ?>" alt="imagen">
</div><?php /**PATH /var/www/html/resources/views/components/application-logo.blade.php ENDPATH**/ ?>