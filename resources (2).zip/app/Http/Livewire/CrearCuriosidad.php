<?php

namespace App\Http\Livewire;

use Livewire\Component;

class CrearCuriosidad extends Component
{
    public function render()
    {
        return view('livewire.crear-curiosidad');
    }
}
