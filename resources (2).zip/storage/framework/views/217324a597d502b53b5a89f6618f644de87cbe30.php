<div class="border  boder-red-400 bg-red-100 text-red-800 font-bold uppercase p-2 text-xs mt-2">
    <p><?php echo e($message); ?></p>
</div>
<?php /**PATH /var/www/html/resources/views/livewire/mostrar-alerta.blade.php ENDPATH**/ ?>