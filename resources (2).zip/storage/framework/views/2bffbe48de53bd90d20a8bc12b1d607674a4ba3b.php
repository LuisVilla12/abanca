
<?php $__env->startSection('title'); ?>
    Noticias
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
<h1 class="bg-titulo px-12 py-6 mt-5 text-white font-bold uppercase text-4xl inline-block">Noticias </h1>
<div class="grid md:grid-cols-2 lg:grid-cols-3 gap-5 container mx-auto">
    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="rounded-xl border-rose-700 mb-7 mt-8">
        <div class="overflow">
            <img src="<?php echo e(asset('uploads/' . $new->urlimg)); ?>" alt="<?php echo e($new->title); ?>">
        </div>
        <div class="p-2 overflow-hidden">
            <p class="text-center font-bold uppercase text-xl my-8 text-titulo"><?php echo e($new->title); ?></p>
            <div class="flex justify-between">
                <p class="text-center font-semibold text-base text-rosa">Fuente: <span class="text-gray-700"><?php echo e($new->autor); ?></span></p> 
                <p class="text-center font-semibold text-base text-rosa">Fecha: <span class="text-gray-700"> <?php echo e($new->date->format('d-m-Y')); ?></span></p> 
            </div>
            <div class="grid place-items-center mt-8" >
                <a  class="text-center font-semibold rounded-lg uppercase bg-rosa px-6 py-4 text-white" href="<?php echo e($new->url); ?>">Ver más</a>                  
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/news/catalogue.blade.php ENDPATH**/ ?>