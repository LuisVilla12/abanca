<div>
    <img src="{{ asset('img/Personajes xicoclass.png') }}" alt="imagen">
</div>